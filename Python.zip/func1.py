 

for x in range(0,20,4):
    print(x)